clear
clc
clf

fid_z = fopen('zfile.txt','r');
fid_u = fopen('ufile.txt','r');
fid_v = fopen('vfile.txt','r');
fid_w = fopen('vorti.txt','r');
fid_d = fopen('bottom.dat','r');
f_x = fopen('parcel_path_x.txt','r');
f_y = fopen('parcel_path_y.txt','r');
f_z = fopen('parcel_path_z.txt','r');
n_particle = 2500;

load runtime.txt
ntime = length(runtime);
ts = runtime(:);

load outputinfo.txt
lx = outputinfo(1);
ly = outputinfo(2);
nx = outputinfo(3);
ny = outputinfo(4);

dx = lx/(nx);
dy = ly/(ny);
[x,y] = meshgrid(0:dx:lx-dx,dy:dy:ly);
[row,col] = size(x);
z = zeros(row,col);
depth = zeros(row,col);

skip = fread(fid_d,1,'int32');
temp = fread(fid_d,[nx,ny],'float32'); % read z line by line
d(1:ny,1:nx) = temp';
skip = fread(fid_d,1,'int32');

colormap jet

for n=1:ntime-1
    n
    
    skip = fread(fid_z,1,'int32');
    temp = fread(fid_z,[nx,ny],'float32');
    z(1:ny,1:nx) = temp';
    skip = fread(fid_z,1,'int32');
    
    skip = fread(fid_u,1,'int32');
    temp = fread(fid_u,[nx,ny],'float32');
    u(1:ny,1:nx) = temp';
    skip = fread(fid_u,1,'int32');
    
    skip = fread(fid_v,1,'int32');
    temp = fread(fid_v,[nx,ny],'float32');
    v(1:ny,1:nx) = temp';
    skip = fread(fid_v,1,'int32');
    
    skip = fread(fid_w,1,'int32');
    temp = fread(fid_w,[nx,ny],'float32');
    w(1:ny,1:nx) = temp';
    skip = fread(fid_w,1,'int32');
    
    skip = fread(f_x,1,'int32');
    temp = fread(f_x,[n_particle],'float32');
    xp(1:n_particle,n) = temp';
    skip = fread(f_x,1,'int32');
    
    skip = fread(f_y,1,'int32');
    temp = fread(f_y,[n_particle],'float32');
    yp(1:n_particle,n) = temp';
    skip = fread(f_y,1,'int32');
    
    skip = fread(f_z,1,'int32');
    temp = fread(f_z,[n_particle],'float32');
    zp(1:n_particle,n) = temp';
    skip = fread(f_z,1,'int32');
    
    subplot(311)
    quiver(x,y,u,v,3,'k')
    axis equal
    axis tight
    hold on
    scatter(xp(1:n_particle,n),yp(1:n_particle,n),'r.')
    hold off
    text(3,24,'flow vector & particles','fontname','times')
    
    subplot(312)
    pcolor(x,y,z)
    shading interp
    axis equal
    axis tight
    hold on
    scatter(xp(1:n_particle,n),yp(1:n_particle,n),'k.')
    hold off
    caxis([-0.3 0.4])
    text(3,24,'water surface & particles','fontname','times')
    
    subplot(313)
    pcolor(x,y,w)
    hold on
    contour(x,y,d,20,'k')
    hold off
    axis equal
    axis tight
    shading interp
    caxis([-1 1])
    text(3,24,'vertical vorticity & bottom','fontname','times')
    
    pause (0.01)
end


fclose all;
